Usage: bootgen fsbl.elf bit u-boot.elf boot.bin

fsbl.elf と bitstream と application.elf から boot.bin を作る python のプログラム。
